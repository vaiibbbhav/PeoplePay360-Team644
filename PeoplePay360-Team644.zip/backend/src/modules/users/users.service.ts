import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { ConflictError, NotFoundError, ValidationError } from '../../shared/errors';
import * as usersRepository from './users.repository';
import {
  CreateUserInput,
  UpdateUserInput,
  UserQueryInput,
  passwordSchema,
} from './users.validators';
import { UserRole } from '../../shared/auth-middleware';
import { sendWelcomeCredentialsEmail } from '../../shared/mailer';
import { getJwtSecret } from '../auth/auth.service';

export const listUsers = async (query: UserQueryInput) => {
  return usersRepository.listUsers({
    search: query.search,
    role: query.role,
    isActive: query.isActive,
  });
};

export const getUserById = async (id: string) => {
  const user = await usersRepository.findUserById(id);
  if (!user) {
    throw new NotFoundError('User account not found');
  }
  return user;
};

export const createUser = async (input: CreateUserInput) => {
  const normalizedEmail = input.email.toLowerCase().trim();
  const existing = await usersRepository.findUserByEmail(normalizedEmail);
  if (existing) {
    throw new ConflictError('A user with this email address already exists');
  }

  // Double check password validation
  const validation = passwordSchema.safeParse(input.password);
  if (!validation.success) {
    throw new ValidationError(
      validation.error.errors[0]?.message ||
        'Password must be at least 8 characters, with 1 uppercase, 1 number, and 1 symbol',
    );
  }

  const salt = await bcrypt.genSalt(10);
  const passwordHash = await bcrypt.hash(input.password, salt);

  const user = await usersRepository.createUser({
    firstName: input.firstName,
    lastName: input.lastName,
    email: normalizedEmail,
    passwordHash,
    role: input.role as UserRole,
    isActive: input.isActive ?? true,
  });

  // Dispatch welcome email with credentials & verification link asynchronously/gracefully
  try {
    const employeeName = `${user.firstName} ${user.lastName}`.trim();

    const JWT_SECRET = getJwtSecret();
    const verificationToken = jwt.sign(
      { userId: user.id, email: user.email, purpose: 'email-verification' },
      JWT_SECRET,
      { expiresIn: '8h' },
    );

    sendWelcomeCredentialsEmail({
      toEmail: normalizedEmail,
      temporaryPassword: 'Set securely via verification link',
      role: input.role,
      employeeName,
      verificationToken,
    }).catch((err) => {
      console.error(
        '[USERS_SERVICE] Non-blocking error sending welcome email:',
        err?.message || err,
      );
    });
  } catch (err: any) {
    console.error('[USERS_SERVICE] Non-blocking error signing token:', err?.message || err);
  }

  return user;
};

export const updateUser = async (id: string, input: UpdateUserInput) => {
  const user = await usersRepository.findUserById(id);
  if (!user) {
    throw new NotFoundError('User account not found');
  }

  const updateData: {
    firstName?: string;
    lastName?: string;
    role?: UserRole;
    isActive?: boolean;
    passwordHash?: string;
  } = {};

  if (input.firstName !== undefined) {
    updateData.firstName = input.firstName;
  }

  if (input.lastName !== undefined) {
    updateData.lastName = input.lastName;
  }

  if (input.role !== undefined) {
    updateData.role = input.role as UserRole;
  }

  if (input.isActive !== undefined) {
    updateData.isActive = input.isActive;
  }

  if (input.password) {
    const validation = passwordSchema.safeParse(input.password);
    if (!validation.success) {
      throw new ValidationError(
        validation.error.errors[0]?.message ||
          'Password must be at least 8 characters, with 1 uppercase, 1 number, and 1 symbol',
      );
    }
    const salt = await bcrypt.genSalt(10);
    updateData.passwordHash = await bcrypt.hash(input.password, salt);
  }

  return usersRepository.updateUser(id, updateData);
};

export const getEmployeeOptions = async () => {
  return usersRepository.listEmployeesForSelection();
};

export const deleteUser = async (id: string, currentUserId?: string) => {
  if (currentUserId && id === currentUserId) {
    throw new ValidationError('You cannot delete your own user account');
  }
  const user = await usersRepository.findUserById(id);
  if (!user) {
    throw new NotFoundError('User account not found');
  }
  return usersRepository.deleteUser(id);
};
